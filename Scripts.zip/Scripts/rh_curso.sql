﻿INSERT INTO rh_curso(
            pk_id_curso, descricao, fk_id_faculdade)
    VALUES (1, 'Medicina', 1);
