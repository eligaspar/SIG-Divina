﻿INSERT INTO rh_faculdade(
            pk_id_faculdade, descricao)
    VALUES (1, 'Medicina');
