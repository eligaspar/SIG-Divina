﻿INSERT INTO adms_solicitacao(
            pk_id_solicitacao, codigo_na_area_solicitante, data, observacao, 
            responsavel, fk_id_funcionario_solicitante, fk_id_area_solicitou, 
            fk_id_centro, fk_id_paciente)
    VALUES (1, 1, '2016-12-24', 'Internar o doente', 
            '', 1, 2, 
            1, 1), (2, 1, '2016-12-25', 'Internar o doente', 
            '', 1, 2, 
            1, 2), (3, 1, '2016-12-24', 'Internar o doente', 
            '', 1, 2, 
            1, 3);
