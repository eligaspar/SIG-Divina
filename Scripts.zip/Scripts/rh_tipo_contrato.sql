﻿INSERT INTO rh_tipo_contrato(
            pk_id_tipo_contrato, descricao)
    VALUES (1, 'Normal');
