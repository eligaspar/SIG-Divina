﻿INSERT INTO rh_candidato(
            pk_id_candidato, ultimo_emprego, observacoes, data_cadastro, 
            fk_id_categoria, fk_id_comprovativo_medico, fk_id_doc_militar, 
            fk_registo_criminal, fk_id_pessoa, fk_id_bi, fk_id_curriculum_vitae, 
            fk_id_certificado_habilitacoes, fk_id_atestado_medico, fk_id_cedula_carteira, 
            fk_id_nivel_academico, numero_candidato, fk_id_tipo_candidatura, 
            fk_id_estado_candidato, ano_inicio_estudos, ano_fim_estudos, 
            fk_id_curso, origem)
    VALUES (1, 'Hospital Prenda', '', '2016-12-12', 
            1, 1, 1, 
            1, 1, 1, 1, 
            1, 1, 1, 
            1, 2012, 1, 
            1, 2010, 2016, 
            1, '');
