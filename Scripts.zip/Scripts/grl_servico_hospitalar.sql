﻿INSERT INTO grl_servico_hospitalar(
            pk_id_servico_hospitalar, codigo_servico_hospitalar, descricao)
    VALUES (1, 'PED', 'Internamento Pedatrico'), 
    (2, 'CNT', 'Centro Nutricional Terapeutico'), (3, 'MED', 'Internamento Medicina'),  (4, 'AMB', 'Ambulatrório'),
    (5, 'EMERG', 'Emergencia');
