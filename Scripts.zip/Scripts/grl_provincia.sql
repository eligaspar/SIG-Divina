﻿INSERT INTO grl_provincia(
            pk_id_provincia, nome_provincia, fk_id_pais)
    VALUES (1, 'Luanda', 1);
