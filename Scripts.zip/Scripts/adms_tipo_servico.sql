﻿INSERT INTO adms_tipo_servico(
            pk_id_tipo_servico, descricao_tipo_servico)
    VALUES (1, 'Internamento');
