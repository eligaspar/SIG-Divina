﻿INSERT INTO rh_funcionario(
            pk_id_funcionario, numero_guia_transferencia, data_admissao, 
            fk_id_categoria, fk_id_tipo_funcionario, fk_id_pessoa, fk_id_cargo, 
            fk_id_centro_hospitalar, fk_id_estado_funcionario, fk_id_contrato)
    VALUES (1, '0001', '2016-11-11', 
            1, 1, 7, 1, 
            1, 1, 1);
