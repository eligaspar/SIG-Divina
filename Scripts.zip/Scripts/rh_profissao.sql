﻿INSERT INTO rh_profissao(
            pk_id_profissao, descricao, tem_especialidade)
    VALUES (1, 'Médico', false), (2, 'Enfermeiro', false);
    
