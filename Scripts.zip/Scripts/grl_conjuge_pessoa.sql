﻿INSERT INTO grl_conjuge_pessoa(
            pk_id_conjuge_pessoa, nome_conjuge, data_nascimento)
    VALUES (1, 'Nádia', '1993-11-11');
