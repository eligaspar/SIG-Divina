﻿INSERT INTO grl_centro_hospitalar(
            pk_id_centro, codigo_centro, fk_id_instituicao)
    VALUES (1, 'HDP', 1);
