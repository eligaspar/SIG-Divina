﻿INSERT INTO grl_especialidade(
            pk_id_especialidade, descricao, sigla_especialidade, fk_id_profissao, 
            flag_medica)
    VALUES (1, 'Internamento', 'INTER', 1, 
            true);
