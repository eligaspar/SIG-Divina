﻿INSERT INTO rh_contrato(
            pk_id_contrato, duracao_meses, data_inicio, data_termino, fk_id_estado_contrato, 
            fk_id_tipo_contrato, fk_id_forma_pagamento, fk_id_tabela_salarial, 
            fk_id_candidato, data_cadastro)
    VALUES (1, 1, '2016-11-11', '2020-11-11', 1, 
            1, 1, 1, 
            1, '10:30');
