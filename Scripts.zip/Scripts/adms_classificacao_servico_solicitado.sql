﻿INSERT INTO adms_classificacao_servico_solicitado(
            pk_id_classificacao_servico_solicitado, descricao_classificacao_servico_solicitado)
    VALUES (1, 'Processo Clinico');
