﻿INSERT INTO grl_tipo_documento_identificacao(
            pk_tipo_documento_identificacao, descricao)
    VALUES (1, 'BI');
