﻿INSERT INTO grl_religiao(
            pk_id_religiao, descricao)
    VALUES (1, 'Católica');
