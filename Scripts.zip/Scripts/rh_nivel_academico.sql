﻿INSERT INTO rh_nivel_academico(
            pk_id_nivel_academico, descricao_nivel_academico)
    VALUES (1, 'Ensino Superior');
