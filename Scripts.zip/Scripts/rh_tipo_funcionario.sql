﻿INSERT INTO rh_tipo_funcionario(
            pk_id_tipo_funcionario, descricao)
    VALUES (2, 'Medico'), (3, 'Enfermeiro');
