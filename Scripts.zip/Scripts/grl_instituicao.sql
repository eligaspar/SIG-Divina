﻿INSERT INTO grl_instituicao(
            pk_id_instituicao, codigo_instituicao, descricao, fk_id_contacto, 
            fk_id_endereco)
    VALUES (1, 'HDP', 'Hospital Divina Providência', 1, 
            1);
