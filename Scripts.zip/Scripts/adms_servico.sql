﻿INSERT INTO adms_servico(
            pk_id_servico, nome_servico, fk_id_tipo_servico, fk_id_area, 
            fk_id_especialidade, pode_ser_agendado)
    VALUES (1, 'Internamento Pediatrico', 1, 1, 
            1, true), (2, 'CNT', 1, 1, 
            1, true), (3, 'Internamento Medicina', 1, 1, 
            1, true);
