﻿INSERT INTO adms_tipo_solicitacao_servico(
            pk_id_tipo_solicitacao, descricao_tipo_solicitacao_servico)
    VALUES (1, 'A'), (2, 'B');
