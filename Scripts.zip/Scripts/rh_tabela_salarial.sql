﻿INSERT INTO rh_tabela_salarial(
            pk_id_tabela_salarial, salario_base, fk_id_cargo)
    VALUES (1, 200000, 1);
