﻿INSERT INTO rh_estado_funcionario(
            pk_id_estado_funcionario, descricao)
    VALUES (1, 'Ativo');
