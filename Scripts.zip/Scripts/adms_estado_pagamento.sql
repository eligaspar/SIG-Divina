﻿INSERT INTO adms_estado_pagamento(
            pk_id_estado_pagamento, descricao_estado_pagamento)
    VALUES (1, 'Pago'), (2, 'Nao Pago');
