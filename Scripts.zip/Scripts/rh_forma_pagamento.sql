﻿INSERT INTO rh_forma_pagamento(
            pk_id_forma_pagamento, descricao)
    VALUES (1, 'Banco');
