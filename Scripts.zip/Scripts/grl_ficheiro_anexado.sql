﻿INSERT INTO grl_ficheiro_anexado(
            pk_id_ficheiro_anexado, ficheiro)
    VALUES (1, 'foto1.jpg');
