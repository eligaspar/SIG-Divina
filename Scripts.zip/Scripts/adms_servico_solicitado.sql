﻿INSERT INTO adms_servico_solicitado(
            pk_id_servico_solicitado, fk_id_solicitacao, fk_id_servico, fk_id_estado_pagamento, 
            observacao, fk_id_classificacao_servico_solicitado, fk_id_tipo_solicitacao, 
            data_atendimento, fk_id_recepcionista, fk_id_preco_preco)
    VALUES (1, 1, 1, 1, 
            '', 1, 1, 
            '2016-11-11', 1, 1), (2, 2, 2, 1, 
            '', 1, 1, 
            '2016-11-11', 1, 2), (3, 3, 3, 1, 
            '', 1, 1, 
            '2016-11-11', 1, 3);
