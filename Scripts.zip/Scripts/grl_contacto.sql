﻿INSERT INTO grl_contacto(
            pk_id_contacto, telefone1, telefone2, email1, email2)
    VALUES (1, '924280158', '', 'pacuco@gmail.com', '');
