﻿INSERT INTO rh_estado_candidato(
            pk_id_estado_candidato, descricao)
    VALUES (1, 'Ativo');
