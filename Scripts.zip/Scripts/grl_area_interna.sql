﻿INSERT INTO grl_area_interna(
            pk_id_area_interna, descricao_area_interna, codigo_area_interna, 
            observacoes)
    VALUES (1, 'Ambulatório', 'AMB', 
            ''), (2, 'Emergência', 'EMERG', 
            ''), (3, 'Internamento', 'INTER', 
            '');
