﻿INSERT INTO rh_tipo_candidatura(
            pk_id_tipo_candidatura, descricao, codigo, estagio)
    VALUES (1, 'Normal', 'N', false);
