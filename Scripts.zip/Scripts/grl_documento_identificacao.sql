﻿INSERT INTO grl_documento_identificacao(
            pk_id_documento, numero_documento, fk_tipo_documento_identificacao)
    VALUES (1, '00045KN042', 1);
