﻿INSERT INTO fin_preco(
            pk_id_preco_preco, valor, data_cadastro, fk_id_servico, fk_id_tipo_solicitacao)
    VALUES (1, 2000, '2016-11-11', 1, 1), (2, 2000, '2016-11-11', 2, 1), (3, 2000, '2016-11-11', 3, 1);
