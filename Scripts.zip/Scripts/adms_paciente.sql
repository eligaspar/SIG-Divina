﻿INSERT INTO adms_paciente(
            pk_id_paciente, numero_paciente, fk_id_pessoa)
    VALUES (1, '001', 1), (2, '002', 2), (3, '003', 3);
