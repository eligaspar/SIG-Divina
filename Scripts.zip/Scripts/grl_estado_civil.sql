﻿INSERT INTO grl_estado_civil(
            pk_id_estado_civil, codigo_estado_civil, descricao)
    VALUES (1, 'S', 'Solteiro');
