﻿INSERT INTO rh_estado_contrato(
            pk_id_estado_contrato, descricao)
    VALUES (1, 'Ativo');
