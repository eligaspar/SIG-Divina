﻿INSERT INTO rh_categoria_profissao(
            pk_id_categoria_profissao, descricao, fk_id_profissao)
    VALUES (1, 1, 1), (2, 2, 2);
    
