﻿INSERT INTO grl_municipio(
            pk_id_municipio, nome_municipio, fk_id_provincia)
    VALUES (1, 'Viana', 1);
