﻿INSERT INTO grl_endereco(
            pk_id_endereco, bairro, numero_casa, fk_id_municipio)
    VALUES (1, 'Grafanil Bar', '001', 1);
