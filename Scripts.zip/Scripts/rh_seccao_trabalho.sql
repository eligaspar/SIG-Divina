﻿INSERT INTO rh_seccao_trabalho(
            pk_id_seccao_trabalho, descricao, fk_id_departamento)
    VALUES (1, 'Internamento', 1);
