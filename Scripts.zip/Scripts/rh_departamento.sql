﻿INSERT INTO rh_departamento(
            pk_id_departamento, descricao)
    VALUES (1, 'Internamento'), (2, 'Ambulatório'), (3, 'EmergÊncia'), (4, 'RH'), (5, 'Admissão');
