﻿INSERT INTO rh_cargo(
            pk_id_cargo, descricao, fk_id_seccao_trabalho)
    VALUES (1, 'Médico', 1), (2, 'Enfermeiro', 1);
